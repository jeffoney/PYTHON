for i in range(1, 151):
    print(i)

for i in range(5,1001,5):
    print(i)

# for i in range(1, 101):
#     print(i)
#     if(i%5==0):
#         print("{} Coding".format(i))
#     if(i%10==0): 
#         print("{} Coding Dojo".format(i))

for j in range(1, 101):
    if j % 10 == 0:
        print("Coding Dojo")
    elif j % 5 == 0:
        print("Coding")
    else:
        print(j)


minimum = int(1) 
maximum = int(500000)
Oddtotal = 0

for number in range(minimum, maximum+1):
    if(number % 2 != 0):
        Oddtotal = Oddtotal + number

print("The Sum of Odd Numbers from {0} to {1} = {2}".format(minimum, maximum, Oddtotal))


for c in range(2018, 0, -4):
    print(c)



lowNum = 2
highNum = 9
mult = 3

for j in range(lowNum, highNum + 1):
    if j % mult == 0:
        print(j)