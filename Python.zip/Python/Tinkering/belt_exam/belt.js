function hide() {
    document.getElementById('alert').style.display = 'none';
}