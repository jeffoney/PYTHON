
function turnOff(element) {
    element.innerText = "Sign In";
}
function hide(element) {
    element.remove();
}
