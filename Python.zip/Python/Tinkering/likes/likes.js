var clicks = 9;

function onClicknm() {
  clicks += 1;
  document.getElementById("nmlikes").innerHTML = clicks;
};

var clicks = 12;

function onClicknk() {
  clicks += 1;
  document.getElementById("nklikes").innerHTML = clicks;
};

var clicks = 9;

function onClickjr() {
  clicks += 1;
  document.getElementById("jrlikes").innerHTML = clicks;
};


