from flask_app import app
import flask_app.controller.users
import flask_app.controller.recipes

from flask import Flask, render_template, request, redirect, session

if __name__ == "__main__":
    app.run(debug=True, host="localhost", port=5000)