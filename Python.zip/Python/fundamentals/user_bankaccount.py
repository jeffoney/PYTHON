
class Bankaccount:
    def __init__(self):
        def deposit(self):
            amount = float(input("Enter amount to be deposited: "))
            self.balance += amount
            print("\n Amount Deposited:", amount)

def withdraw(self):
        amount = float(input("Enter amount to be withdrawn: "))
        if self.balance >= amount:
            self.balance -= amount
            print("\n You Withdrew:", amount)
        else:
            print("\n Insufficient balance  ")

def display(self):
        print("\n Net Available Balance =", self.balance)

class Bank_Account:
    def __init__(self):
        self.balance=72.43
        print("Hello Jeffrey,")
        def display(self):
            print("\n Available Balance=",self.balance)

    def withdraw(self):
            amount = float(input("Please enter amount to be Withdrawn: "))
            if self.balance>=amount:
                self.balance-=amount
                print("\n You Withdrew:", amount)
            else:
                print("\n Insufficient funds  ")

    def deposit(self):
            amount=float(input("Please enter amount to be Deposited: "))
            self.balance += amount
            print("\n Amount Deposited:",amount)

    def display(self):
        print("\n Available Balance=",self.balance)


s = Bank_Account()

s.display()
s.deposit()
s.display()
s.withdraw()
s.display()

