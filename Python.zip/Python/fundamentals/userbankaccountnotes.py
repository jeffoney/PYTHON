# BankAccount class
class Bankaccount:
    def __init__(self):
        # Function to deposite amount
        def deposit(self):
            amount = float(input("Enter amount to be deposited: "))
            self.balance += amount
            print("\n Amount Deposited:", amount)
        # Function to withdraw the amount
def withdraw(self):
        amount = float(input("Enter amount to be withdrawn: "))
        if self.balance >= amount:
            self.balance -= amount
            print("\n You Withdrew:", amount)
        else:
            print("\n Insufficient balance  ")
            # Function to display the amount
def display(self):
        print("\n Net Available Balance =", self.balance)
        # Python program to create Bankaccount class
# with both a deposit() and a withdraw() function
class Bank_Account:
    def __init__(self):
        self.balance=72.43
        print("Hello Jeffrey,")
        def display(self):
            print("\n Available Balance=",self.balance)

    def withdraw(self):
            amount = float(input("Please enter amount to be Withdrawn: "))
            if self.balance>=amount:
                self.balance-=amount
                print("\n You Withdrew:", amount)
            else:
                print("\n Insufficient funds  ")

    def deposit(self):
            amount=float(input("Please enter amount to be Deposited: "))
            self.balance += amount
            print("\n Amount Deposited:",amount)

    def display(self):
        print("\n Available Balance=",self.balance)

# Driver code

# creating an object of class
s = Bank_Account()
# Calling functions with that class object
s.display()
s.deposit()
s.withdraw()
s.display()

